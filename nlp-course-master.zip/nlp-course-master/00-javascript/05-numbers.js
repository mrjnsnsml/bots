const a = 2;
const b = 7;

console.log(b + a);
console.log(b - a);
console.log(b * a);
console.log(b / a);
console.log(b % a);

const c = 3.6;
const d = 4.5;

console.log('Ceil '+Math.ceil(c));
console.log('Floor ' + Math.floor(c));
console.log('Round ' + Math.round(c));

console.log('Ceil ' + Math.ceil(d));
console.log('Floor ' + Math.floor(d));
console.log('Round ' + Math.round(d));

console.log(Math.max(8, 7, 1, 9, 10, -2));
console.log(Math.min(8, 7, 1, 9, 10, -2));

console.log(Math.pow(2, 3));
console.log(2 ** 3);

console.log(Math.random());

//1-6
console.log(Math.floor(Math.random() * 6) + 1);