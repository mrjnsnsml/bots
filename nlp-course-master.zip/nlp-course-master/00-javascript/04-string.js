const name = 'John';
const age = 20;
const message = `Hello ${name} Your age is ${age * 2}`;
console.log(message);
console.log(message.length);
console.log(message[0]);

console.log(message.slice(2, 5));
console.log(message.substr(2, 5));

console.log(message.toUpperCase());
console.log(message.toLowerCase());
