function multiply(b) {
    let i = 15;
    for (let i = 0; i < 10; i += 1) {
        console.log(i * b);
    }
    console.log(i); 
}


multiply(5);
