let message;
console.log(message);
let another = null;
console.log(another);

console.log(typeof message);
console.log(typeof another);
console.log(typeof 'a');
console.log(typeof 7);
console.log(typeof {});

console.log(message * 2);
console.log(another * 2);

if (0) {
    console.log('yes');
} else {
    console.log('no');
}
