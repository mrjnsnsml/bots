const projectId = "customsdk-uuvw";
const port = 3000;
const languageCode = "en-US"


const socketIo = require('socket.io');
const http = require('http')
const cors = require('cors');
const express = require('express');
const path = require('path');

const uuid = require('uuid');
const df = require('dialogflow');



//create express app
const app = express();

app.use(cors());

app.get('/', function(req, res) {
    res.sendFile(path.join('D:/CustmSDKChat/ui/index.html'));



});


server = http.createServer(app);

io = socketIo(server);

server.listen(port, () => {
    console.log("Runing server on port %s", port)

});


io.on('connect', (client) => {
    console.log(`Client connected [id=${client.id}]`);
    client.emit('server_setup', `Server connected [id=${client.id}]`);

    client.on('message', async function(msg) {
        
        const results = await detectIntent(msg);
        console.log(results);

        client.emit('returnResults', results)
        


    })
    



});

function setupDialogFlow() {
    sessionId = uuid.v4();

    sessionClient = new df.SessionsClient();

    sessionPath = sessionClient.sessionPath(projectId, sessionId);

    request = {
        session:sessionPath,
        queryInput: {}


    }




}

async function detectIntent(text) {

    request.queryInput.text = {
        languageCode: languageCode,
        text: text


    };

    console.log(request);

    const responses = await sessionClient.detectIntent(request);
    return responses;
    



}


setupDialogFlow();
