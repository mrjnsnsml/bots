function power(a, b) {
    return a ** b;
}

function powerFn(b) {
    return (a) => a ** b; 
}

console.log(power2(2));
console.log(power3(2));
console.log(power2(3));
console.log(power3(3));