let message = 'Hello Worlds';
message = 'Something';
let age = 15;
console.log(message, age);
